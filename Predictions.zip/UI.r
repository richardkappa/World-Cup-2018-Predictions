library("readr")
library("dplyr")
library("shiny")
library("ggplot2")
library("plotly")

shinyUI(fluidPage(
  titlePanel(title=div(img(src="LV_computer.png", height = 70), "LV Pricing Euro 2020 Prediction Competition", img(src="hearts.png", height = 80)), windowTitle = "LV Pricing Euro 2020 Prediction Competition"),
  dataTableOutput(outputId = "LeagueTable"),
  plotlyOutput("plot")
)
)
